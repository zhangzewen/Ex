这个是纯粹是livevent-1.4.X版本上一个模子刻出来的，就是想自己看看libevent的工作工作流程以及Reactor模式
当然这个复制品剔除了timeout和signal，单纯的I/O，现在还是跑的一塌糊涂
这个只是个人练习使用。
你要是不拍抓狂的话，可以试试
当然，我会不停的去完善它

This just a copy of libevent-1.4.x, I delete timeout and signal from the source code for exercise
By now， it dose not work well！
